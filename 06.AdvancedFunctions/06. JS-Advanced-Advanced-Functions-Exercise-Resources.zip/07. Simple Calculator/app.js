function calculator() {
    // TODO:
}




